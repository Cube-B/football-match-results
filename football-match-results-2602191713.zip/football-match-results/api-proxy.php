<?php
/**
 * api-proxy.php — Football Match Results
 * ═══════════════════════════════════════════════════════
 * เรียกโดย cPanel Cron Job ทุก 2 นาที
 * ดึงผลการแข่งขันจาก SOURCE_URL → บันทึกลง cache/results.html
 *
 * Cron ใน cPanel:
 *   * /2 * * * *  /usr/local/bin/php /home/zeezabet/public_html/football-match-results/api-proxy.php
 * ═══════════════════════════════════════════════════════
 */

define('FMR_APP', true);
require_once __DIR__ . '/includes/Config.php';
require_once __DIR__ . '/includes/Cache.php';

$startTime = microtime(true);

// Security: HTTP call ต้องมี cron_secret
if (PHP_SAPI !== 'cli') {
    $secret = Config::get('CRON_SECRET', 'change_this');
    $given  = $_GET['cron_secret'] ?? '';
    if (!hash_equals($secret, $given)) {
        http_response_code(403);
        die(json_encode(['ok' => false, 'error' => 'Forbidden']));
    }
    header('Content-Type: application/json');
}

$sourceUrl = Config::get('SOURCE_URL');
if (!$sourceUrl) {
    exit_result('SOURCE_URL not set in .env', false);
}

$html = fetchUrl($sourceUrl);
if ($html === null) {
    exit_result('Failed to fetch from source URL', false);
}
if (trim($html) === '') {
    exit_result('Empty response from source', false);
}
if (!Cache::write($html)) {
    exit_result('Failed to write cache file', false);
}

$elapsed = round((microtime(true) - $startTime) * 1000);
exit_result("OK — {$elapsed}ms — " . number_format(strlen($html)) . " bytes", true);

// ── Functions ─────────────────────────────────────────────────────────────

function fetchUrl(string $url): ?string {
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_USERAGENT      => 'YamchaFMR/1.0 (+https://yamcha.info)',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS      => 3,
            CURLOPT_ENCODING       => 'gzip, deflate',
        ]);
        $body = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);
        if ($err)          { log_msg("cURL error: $err"); return null; }
        if ($code !== 200) { log_msg("HTTP $code from source"); return null; }
        return $body ?: null;
    }
    $ctx  = stream_context_create(['http' => ['timeout' => 20, 'user_agent' => 'YamchaFMR/1.0']]);
    $body = @file_get_contents($url, false, $ctx);
    return $body !== false ? $body : null;
}

function exit_result(string $msg, bool $ok): never {
    log_msg(($ok ? '[OK] ' : '[FAIL] ') . $msg);
    if (PHP_SAPI !== 'cli') {
        http_response_code($ok ? 200 : 500);
        echo json_encode(['ok' => $ok, 'message' => $msg, 'time' => date('c')]);
    } else {
        echo "[" . date('H:i:s') . "] " . ($ok ? '✓' : '✗') . " $msg\n";
    }
    exit($ok ? 0 : 1);
}

function log_msg(string $msg): void {
    file_put_contents(
        __DIR__ . '/cache/proxy.log',
        "[" . date('Y-m-d H:i:s') . "] $msg\n",
        FILE_APPEND | LOCK_EX
    );
}
