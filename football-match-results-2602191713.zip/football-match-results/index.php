<?php
/**
 * index.php — Football Match Results Monitor
 * ═══════════════════════════════════════════════════════
 * แสดงผลการแข่งขัน พร้อม HT Score, Corner Stats, Score Detail
 * เหมือนกับที่ WordPress Plugin จะแสดง
 *
 * เข้าถึง: https://yamcha.info/football-match-results/?secret=ADMIN_SECRET
 * ═══════════════════════════════════════════════════════
 */

define('FMR_APP', true);
date_default_timezone_set('Asia/Bangkok');
require_once __DIR__ . '/includes/Config.php';
require_once __DIR__ . '/includes/Cache.php';

// Auth
define('REQUIRE_AUTH', true);
if (REQUIRE_AUTH) {
    $adminSecret = Config::get('ADMIN_SECRET', 'change_me');
    $given       = $_GET['secret'] ?? $_COOKIE['fmr_admin'] ?? '';
    if (!hash_equals($adminSecret, $given)) {
        http_response_code(403);
        echo '<!DOCTYPE html><html><head><title>Football Match Results</title>
        <style>body{font:14px system-ui;background:#0f1117;color:#e0e0e0;display:flex;
        align-items:center;justify-content:center;min-height:100vh;margin:0}
        form{background:#161922;padding:32px;border-radius:8px;text-align:center;min-width:300px}
        h2{margin:0 0 16px;font-size:18px}
        input{padding:9px 14px;border:1px solid #374151;background:#0f1117;color:#e0e0e0;
        border-radius:4px;margin:8px 0;font-size:14px;width:100%;box-sizing:border-box}
        button{padding:9px 20px;background:#3b82f6;color:#fff;border:none;border-radius:4px;
        cursor:pointer;width:100%;font-size:14px;margin-top:8px}</style>
        </head><body><form method="get">
        <h2>🏆 FMR Monitor</h2><p style="color:#6b7280;font-size:12px;margin:0 0 12px">Football Match Results</p>
        <input type="password" name="secret" placeholder="Admin Password" autofocus>
        <button type="submit">Enter</button></form></body></html>';
        exit;
    }
    setcookie('fmr_admin', $given, time() + 86400, '/', '', true, true);
}

// Ajax refresh endpoint
if (isset($_GET['ajax'])) {
    header('Content-Type: application/json');
    $html = Cache::read();
    if (!$html) { echo json_encode(['html'=>null]); exit; }
    $meta = Cache::meta();
    echo json_encode([
        'html'         => applyTranslation($html),
        'stale'        => Cache::isStale(),
        'updated_time' => $meta['updated_at'] ? date('H:i:s', $meta['updated_at']) : null,
    ]);
    exit;
}

// Manual fetch
$fetchMsg = null;
if (isset($_GET['fetch'])) {
    $sourceUrl = Config::get('SOURCE_URL');
    if ($sourceUrl && function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt_array($ch, [CURLOPT_URL=>$sourceUrl,CURLOPT_RETURNTRANSFER=>true,
            CURLOPT_TIMEOUT=>20,CURLOPT_USERAGENT=>'YamchaFMR/1.0',
            CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_ENCODING=>'gzip']);
        $html = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code === 200 && $html) {
            Cache::write($html);
            $fetchMsg = ['ok'=>true,'msg'=>'Fetched successfully ('.number_format(strlen($html)).' bytes)'];
        } else {
            $fetchMsg = ['ok'=>false,'msg'=>"Fetch failed — HTTP $code"];
        }
    }
}

// Translation function (PHP side for monitor)
function applyTranslation(string $html): string {
    // Score detail patterns (results-specific) — process first (longer patterns)
    $html = preg_replace('/90 Phút \[(\d+)-(\d+)\]/u',  'FT [$1-$2]',  $html);
    $html = preg_replace('/120 Phút \[(\d+)-(\d+)\]/u', 'AET [$1-$2]', $html);
    // Vòng patterns
    $html = preg_replace('/Vòng (\d+)\/(\d+)/u', 'Round of $2', $html);
    $html = preg_replace('/Vòng (\d+)/u',        'Matchday $1', $html);

    $map = [
        // Headers
        'Chủ nhà'              => 'Home',
        'Khách'                => 'Away',
        'Tỷ số'               => 'Score',
        // Stages
        'Vòng Loại Trực Tiếp' => 'Knockout Round',
        'Vòng Loại'           => 'Qualifying',
        'Bán kết'             => 'Semi-final',
        'Chung kết'           => 'Final',
        'Tứ kết'             => 'Quarter-final',
        // Match detail (results-specific)
        'Lượt đi'            => '1st Leg',
        'Lượt về'            => '2nd Leg',
        'Tiến vào vòng trong' => '→ Advances',
        '90 Phút'             => 'FT',
        '120 Phút'            => 'AET',
        'Phút'                => 'min',
        // Countries
        'Tây Ban Nha'         => 'Spain',
        'Phần Lan'            => 'Finland',
        'Ba Lan'              => 'Poland',
        'Bồ Đào Nha'          => 'Portugal',
        'Bắc Ireland'         => 'N. Ireland',
        'Thụy Điển'           => 'Sweden',
        'Thụy Sĩ'             => 'Switzerland',
        'Na Uy'               => 'Norway',
        'Pháp'                => 'France',
        'Hà Lan'              => 'Netherlands',
        'Đức'                 => 'Germany',
        'Ý'                   => 'Italy',
        'Bỉ'                  => 'Belgium',
        'Áo'                  => 'Austria',
        'Nữ '                 => "Women's ",
    ];
    return str_replace(array_keys($map), array_values($map), $html);
}

$meta      = Cache::meta();
$age       = Cache::ageSeconds();
$isStale   = Cache::isStale();
$cacheOk   = Cache::exists();
$keys      = Config::apiKeys();
$logFile   = __DIR__ . '/cache/proxy.log';

function fmtAge(int $s): string {
    if ($s === PHP_INT_MAX) return 'Never';
    if ($s < 60) return "{$s}s ago";
    return round($s/60,1).'min ago';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>🏆 Football Match Results — Monitor</title>
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',system-ui,Arial,sans-serif;background:#080b10;color:#e0e0e0;font-size:13px;min-height:100vh}
a{color:#60a5fa;text-decoration:none}
.layout{display:grid;grid-template-columns:300px 1fr;min-height:100vh}
@media(max-width:860px){.layout{grid-template-columns:1fr}}

/* Sidebar */
.sidebar{background:#0d1017;border-right:1px solid #1e2230;display:flex;flex-direction:column;position:sticky;top:0;height:100vh;overflow-y:auto}
.sidebar-header{padding:18px 16px 14px;border-bottom:1px solid #1e2230;background:#0a0d14}
.sidebar-header h1{font-size:14px;font-weight:700;color:#f9fafb;display:flex;align-items:center;gap:8px}
.sidebar-header p{font-size:11px;color:#6b7280;margin-top:4px}
.status-grid{padding:12px;display:flex;flex-direction:column;gap:8px}
.card{background:#13161e;border:1px solid #1e2230;border-radius:6px;padding:10px 12px}
.card-label{font-size:10px;color:#6b7280;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px}
.card-value{font-size:13px;font-weight:600}
.card-sub{font-size:11px;color:#6b7280;margin-top:2px}
.ok{color:#22c55e}.warn{color:#f59e0b}.err{color:#ef4444}
.dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#374151;margin-right:6px;vertical-align:middle}
.dot.ok{background:#22c55e;animation:pulse 2s infinite}
.dot.warn{background:#f59e0b}
.dot.err{background:#ef4444}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
.btn-group{padding:0 12px 12px;display:flex;flex-direction:column;gap:6px}
.btn{display:block;text-align:center;padding:8px;border-radius:5px;font-size:12px;font-weight:600;cursor:pointer;border:none}
.btn-primary{background:#2563eb;color:#fff}
.btn-primary:hover{background:#1d4ed8}
.btn-ghost{background:#1e2230;color:#9ca3af}
.btn-ghost:hover{background:#252836;color:#e5e7eb}
.log-section{padding:0 12px 12px}
.log-section h3{font-size:11px;color:#6b7280;text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px}
.log-box{background:#0a0d14;border:1px solid #1e2230;border-radius:4px;padding:8px;font-family:monospace;font-size:10px;color:#6b7280;max-height:180px;overflow-y:auto;line-height:1.6;white-space:pre-wrap;word-break:break-all}
.log-ok{color:#22c55e}.log-fail{color:#ef4444}
.key-pill{display:inline-block;padding:2px 8px;background:#1e2c3e;color:#60a5fa;border-radius:3px;font-size:10px;font-family:monospace;margin:2px}

/* Main */
.main{display:flex;flex-direction:column}
.preview-header{background:#0d1017;border-bottom:1px solid #1e2230;padding:14px 20px;display:flex;align-items:center;gap:12px;position:sticky;top:0;z-index:20}
.preview-header h2{font-size:13px;font-weight:700;color:#9ca3af}
.preview-label{font-size:10px;background:#1e2c3e;color:#60a5fa;padding:2px 8px;border-radius:3px;font-weight:600}
.preview-time{margin-left:auto;font-size:11px;color:#4b5563}
.auto-badge{font-size:10px;color:#22c55e;background:#0d2218;padding:2px 8px;border-radius:3px}
.fetch-banner{margin:12px 20px 0;padding:10px 14px;border-radius:5px;font-size:12px;font-weight:600}
.fetch-banner.ok{background:#0d2218;color:#22c55e;border-left:3px solid #22c55e}
.fetch-banner.err{background:#1f0f0f;color:#ef4444;border-left:3px solid #ef4444}
.widget-wrap{flex:1;padding:16px 20px;display:flex;flex-direction:column}

/* Widget */
.fmr-widget{background:#0f1117;border-radius:8px;box-shadow:0 4px 24px rgba(0,0,0,.5);overflow:hidden;flex:1;display:flex;flex-direction:column}
.fmr-topbar{display:flex;align-items:center;gap:8px;padding:7px 14px;background:#161922;border-bottom:1px solid #252830;font-size:11px;color:#6b7280}
.fmr-topbar .dot{margin-right:0}
.fmr-topbar-label{font-weight:700;color:#9ca3af}
.fmr-topbar-time{margin-left:auto}
.fmr-scroll{overflow-y:auto;flex:1;scrollbar-width:thin;scrollbar-color:#374151 transparent}
.fmr-scroll::-webkit-scrollbar{width:4px}
.fmr-scroll::-webkit-scrollbar-thumb{background:#374151;border-radius:2px}

/* Results content */
.fmr-scroll .as-competition-wrapper{border-bottom:1px solid #1e222c}
.fmr-scroll .as-league_title,
.fmr-scroll .as-match_competition{display:flex;align-items:center;gap:8px;padding:7px 14px;background:#161922;font-weight:700;font-size:11px;color:#d1d5db;letter-spacing:.5px;text-transform:uppercase;border-bottom:1px solid #252830;position:sticky;top:0;z-index:5}
.fmr-scroll .as-league_title img,
.fmr-scroll .as-match_competition img{width:18px;height:18px;object-fit:contain}
.fmr-scroll .as-match__item{border-bottom:1px solid #1a1e27}
.fmr-scroll .as-match__item:hover{background:#13161e}
.fmr-scroll .as-match__item--wrap{display:flex;align-items:center;padding:9px 14px;gap:10px}
.fmr-scroll .as-match__sm{min-width:72px}
.fmr-scroll .as-match__label{display:flex;flex-direction:column;gap:2px}
.fmr-scroll .as-match__label-item{font-size:11px;color:#9ca3af;white-space:nowrap}
.fmr-scroll .as-match__teams,
.fmr-scroll .as-match__scores{display:flex;align-items:center;flex:1;gap:6px}
.fmr-scroll .as-match__team{display:flex;align-items:center;gap:5px;flex:1;color:inherit;min-width:0}
.fmr-scroll .as-match__team--home{justify-content:flex-end}
.fmr-scroll .as-match__team--home .as-match__team--name{order:-1;text-align:right}
.fmr-scroll .as-match__team--logo{width:20px;height:20px;object-fit:contain;flex-shrink:0}
.fmr-scroll .as-match__team--name{font-size:13px;font-weight:500;color:#e5e7eb;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* ── Score Board (Results specific) ─────────────────── */
.fmr-scroll .as-scoreboard{min-width:64px;text-align:center;flex-shrink:0}
.fmr-scroll .as-score-vs{display:inline-flex;align-items:center;gap:4px;font-weight:700;font-size:15px;padding:4px 10px;border-radius:5px;background:#1e2230;min-width:54px;justify-content:center}

/* Home Win */
.fmr-scroll .as-score-vs-xoilacz__home-win{background:#0d2218;border:1px solid #14532d}
.fmr-scroll .as-score-vs-xoilacz__home-win .as-home-score{color:#22c55e}
/* Away Win */
.fmr-scroll .as-score-vs-xoilacz__away-win{background:#0f172a;border:1px solid #1e3a5f}
.fmr-scroll .as-score-vs-xoilacz__away-win .as-away-score{color:#60a5fa}
/* Draw */
.fmr-scroll .as-score-vs-xoilacz__draw{background:#1c1917;border:1px solid #292524}
.fmr-scroll .as-score-vs-xoilacz__draw .as-home-score,
.fmr-scroll .as-score-vs-xoilacz__draw .as-away-score{color:#d6d3d1}
/* Winner score */
.fmr-scroll .as-winner{font-weight:800}
.fmr-scroll .as-score-vs b{color:#374151;font-weight:400;font-size:13px}

/* HT & Corner */
.fmr-scroll .as-match__ht,
.fmr-scroll .as-match__corner{font-size:11px;color:#6b7280;min-width:52px;text-align:center;flex-shrink:0}
.fmr-scroll .as-ht-btn{display:inline-flex;gap:2px;background:#1e2230;padding:2px 6px;border-radius:3px;font-size:11px}

/* Score Detail — result info (extra time, leg info, advances) */
.fmr-scroll .as-score-detail{padding:3px 14px 8px;font-size:11px;color:#9ca3af;font-style:italic;background:#0d0f15;border-top:1px dashed #1e2230;line-height:1.5}
.fmr-scroll .as-score-detail:empty{display:none}

.fmr-scroll .as-active{color:#f59e0b;font-weight:700}
.fmr-scroll .as-separator{color:#374151;margin:0 2px}
.fmr-scroll .as-label-item-win{color:#22c55e}
.fmr-scroll .as-label-item-no-win{color:#9ca3af}
.fmr-scroll .as-match__teams.as-d-none{display:none!important}

/* Loading */
.fmr-loading{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:60px 20px;gap:14px;color:#4b5563}
.fmr-spinner{width:32px;height:32px;border:3px solid #1e2230;border-top-color:#3b82f6;border-radius:50%;animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

@media(max-width:540px){
    .fmr-scroll .as-match__ht,
    .fmr-scroll .as-match__corner{display:none!important}
    .fmr-scroll .as-match__team--name{font-size:11px}
    .fmr-scroll .as-match__item--wrap{padding:8px 10px}
}
</style>
</head>
<body>
<div class="layout">

<!-- ═══ SIDEBAR ══════════════════════════════════════════════════════════ -->
<aside class="sidebar">
  <div class="sidebar-header">
    <h1>🏆 FMR Monitor</h1>
    <p>Football Match Results — yamcha.info</p>
  </div>

  <div class="status-grid">
    <div class="card">
      <div class="card-label">Cache Status</div>
      <?php if (!$cacheOk): ?>
        <div class="card-value err"><span class="dot err"></span>No Cache</div>
        <div class="card-sub">Click "Fetch Now" to populate</div>
      <?php elseif ($isStale): ?>
        <div class="card-value warn"><span class="dot warn"></span>Stale</div>
        <div class="card-sub">Age: <?= fmtAge($age) ?> / TTL: <?= Config::cacheTtl() ?>s</div>
      <?php else: ?>
        <div class="card-value ok"><span class="dot ok"></span>Fresh</div>
        <div class="card-sub">Age: <?= fmtAge($age) ?> / TTL: <?= Config::cacheTtl() ?>s</div>
      <?php endif; ?>
    </div>

    <div class="card">
      <div class="card-label">Last Updated</div>
      <div class="card-value"><?= $meta['updated_iso'] ? date('d M H:i:s', $meta['updated_at']) : '—' ?></div>
      <div class="card-sub"><?= isset($meta['size']) ? number_format($meta['size']).' bytes' : 'No data' ?></div>
    </div>

    <div class="card">
      <div class="card-label">API Endpoint</div>
      <div class="card-value" style="font-size:11px;font-family:monospace;word-break:break-all">
        /football-match-results/api.php
      </div>
      <div class="card-sub"><?= count($keys) ?> active key(s)</div>
    </div>

    <?php if ($keys): ?>
    <div class="card">
      <div class="card-label">Plugin Keys (masked)</div>
      <?php foreach ($keys as $k): ?>
        <span class="key-pill"><?= htmlspecialchars(substr($k,0,10)) ?>•••</span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <div class="btn-group">
    <a class="btn btn-primary" href="?<?= REQUIRE_AUTH?'secret='.urlencode(Config::get('ADMIN_SECRET')).'&':'' ?>fetch=1">
      🔄 Fetch Now
    </a>
    <a class="btn btn-ghost" href="api.php?key=<?= htmlspecialchars($keys[0]??'') ?>" target="_blank">
      🧪 Test API Response
    </a>
    <a class="btn btn-ghost" href="api-proxy.php?cron_secret=<?= htmlspecialchars(Config::get('CRON_SECRET')) ?>" target="_blank">
      ⚡ Run Cron Manually
    </a>
  </div>

  <?php if (file_exists($logFile)): ?>
  <div class="log-section">
    <h3>📋 Cron Log (recent)</h3>
    <div class="log-box"><?php
      foreach (array_slice(array_reverse(file($logFile, FILE_IGNORE_NEW_LINES)), 0, 20) as $line) {
          $cls = str_contains($line,'[OK]') ? 'log-ok' : (str_contains($line,'[FAIL]') ? 'log-fail' : '');
          echo '<span class="'.$cls.'">'.htmlspecialchars($line)."</span>\n";
      }
    ?></div>
  </div>
  <?php endif; ?>
</aside>

<!-- ═══ MAIN PREVIEW ══════════════════════════════════════════════════════ -->
<main class="main">
  <div class="preview-header">
    <h2>LIVE PREVIEW</h2>
    <span class="preview-label">Identical to WordPress Plugin output</span>
    <span class="auto-badge">⟳ Auto-refresh 30s</span>
    <span class="preview-time" id="refreshCountdown">Next: 30s</span>
  </div>

  <?php if ($fetchMsg): ?>
  <div class="fetch-banner <?= $fetchMsg['ok']?'ok':'err' ?>">
    <?= $fetchMsg['ok']?'✅':'❌' ?> <?= htmlspecialchars($fetchMsg['msg']) ?>
  </div>
  <?php endif; ?>

  <div class="widget-wrap">
    <div class="fmr-widget">

      <div class="fmr-topbar">
        <span class="dot <?= !$cacheOk?'err':($isStale?'warn':'ok') ?>"></span>
        <span class="fmr-topbar-label" id="statusLabel">
          <?= !$cacheOk?'No Cache':($isStale?'Stale Cache':'Live') ?>
        </span>
        <span class="fmr-topbar-time" id="updatedTime">
          <?= $meta['updated_at'] ? 'Updated '.date('H:i:s',$meta['updated_at']) : '' ?>
        </span>
      </div>

      <div class="fmr-scroll" id="resultsContent">
        <?php
        $html = Cache::read();
        if ($html):
            echo applyTranslation($html);
        else: ?>
          <div class="fmr-loading">
            <div class="fmr-spinner"></div>
            <p>No cache data — click "Fetch Now" to load</p>
          </div>
        <?php endif; ?>
      </div>

    </div>
  </div>
</main>
</div>

<script>
(function () {
    let countdown = 30;
    const label   = document.getElementById('refreshCountdown');
    const content = document.getElementById('resultsContent');
    const statusL = document.getElementById('statusLabel');
    const updTime = document.getElementById('updatedTime');

    function tick() {
        countdown--;
        if (label) label.textContent = 'Next: ' + countdown + 's';
        if (countdown <= 0) refresh();
    }

    async function refresh() {
        countdown = 30;
        try {
            const res  = await fetch(location.href.split('?')[0] + '?ajax=1', { cache: 'no-store' });
            const data = await res.json();
            if (data.html && content) {
                content.style.opacity = '0';
                setTimeout(() => {
                    content.innerHTML     = data.html;
                    content.style.opacity = '1';
                    if (statusL) statusL.textContent = data.stale ? '⚠ Stale' : 'Live';
                    if (updTime && data.updated_time) updTime.textContent = 'Updated ' + data.updated_time;
                }, 200);
            }
        } catch(e) { console.warn('[FMR Monitor]', e); }
    }

    setInterval(tick, 1000);
    if (content) content.style.transition = 'opacity .2s';
})();
</script>
</body>
</html>
