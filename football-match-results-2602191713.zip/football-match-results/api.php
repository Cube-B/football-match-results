<?php
/**
 * api.php — Football Match Results API
 * Plugin เรียก: GET https://yamcha.info/football-match-results/api.php
 * Header: X-Yamcha-Key: <key>
 */

define('FMR_APP', true);
require_once __DIR__ . '/includes/Config.php';
require_once __DIR__ . '/includes/Cache.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: X-Yamcha-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// Validate Key
$key = trim($_SERVER['HTTP_X_YAMCHA_KEY'] ?? $_GET['key'] ?? '');
if (!Config::isValidKey($key)) {
    out(401, false, null, 'Invalid or missing API key', 'INVALID_KEY');
}

// Rate limit: 60 req/min per IP
$ip   = $_SERVER['REMOTE_ADDR'] ?? 'x';
$rdir = sys_get_temp_dir() . '/fmr_rate/';
if (!is_dir($rdir)) @mkdir($rdir, 0700, true);
$rf   = $rdir . md5($ip) . '.json';
$rd   = file_exists($rf) ? json_decode(file_get_contents($rf), true) : ['n'=>0,'t'=>time()];
if (time() - $rd['t'] > 60) $rd = ['n'=>0,'t'=>time()];
$rd['n']++;
file_put_contents($rf, json_encode($rd), LOCK_EX);
if ($rd['n'] > 60) out(429, false, null, 'Rate limit exceeded', 'RATE_LIMIT');

// Serve cache
if (!Cache::exists()) {
    out(503, false, null, 'Cache not ready — cron may not have run yet', 'CACHE_EMPTY');
}

$html = Cache::read();
$meta = Cache::meta();
$age  = Cache::ageSeconds();

header('Cache-Control: public, max-age=90');
header('X-Cache-Age: ' . $age);
if (Cache::isStale()) header('X-Cache-Warning: Stale cache (' . $age . 's old)');

out(200, true, $html, 'OK', null, $meta, $age);

function out(int $code, bool $ok, ?string $html, string $msg, ?string $err, array $meta = [], int $age = 0): never {
    http_response_code($code);
    $r = ['success' => $ok];
    if ($ok) {
        $r['html']        = $html;
        $r['updated_at']  = $meta['updated_at']  ?? null;
        $r['updated_iso'] = $meta['updated_iso'] ?? null;
        $r['cache_age']   = $age;
    } else {
        $r['error'] = $msg;
        $r['code']  = $err;
    }
    echo json_encode($r, JSON_UNESCAPED_UNICODE);
    exit;
}
