<?php
defined('FMR_APP') or die('No direct access');

class Cache {
    private static string $dir  = '';
    private static string $file = '';
    private static string $meta = '';

    private static function init(): void {
        if (self::$dir) return;
        self::$dir  = dirname(__DIR__) . '/cache/';
        self::$file = self::$dir . 'results.html';
        self::$meta = self::$dir . 'meta.json';
    }

    public static function write(string $html): bool {
        self::init();
        if (!is_dir(self::$dir)) {
            mkdir(self::$dir, 0755, true);
            file_put_contents(self::$dir . '.htaccess', "Order Deny,Allow\nDeny from all\n");
        }
        $tmp = self::$file . '.tmp';
        if (file_put_contents($tmp, $html, LOCK_EX) === false) return false;
        if (!rename($tmp, self::$file)) return false;

        file_put_contents(self::$meta, json_encode([
            'updated_at'  => time(),
            'updated_iso' => date('c'),
            'size'        => strlen($html),
        ]), LOCK_EX);
        return true;
    }

    public static function read(): ?string {
        self::init();
        if (!file_exists(self::$file)) return null;
        return file_get_contents(self::$file) ?: null;
    }

    public static function meta(): array {
        self::init();
        if (!file_exists(self::$meta)) return [];
        return json_decode(file_get_contents(self::$meta), true) ?? [];
    }

    public static function ageSeconds(): int {
        self::init();
        if (!file_exists(self::$file)) return PHP_INT_MAX;
        return time() - (int) filemtime(self::$file);
    }

    public static function isStale(): bool {
        return self::ageSeconds() > Config::cacheTtl();
    }

    public static function exists(): bool {
        self::init();
        return file_exists(self::$file);
    }
}
