<?php
defined('FMR_APP') or die('No direct access');

class Config {
    private static array $env = [];

    public static function load(): void {
        if (self::$env) return;
        $file = dirname(__DIR__) . '/.env';
        if (!file_exists($file)) return;
        foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            $line = trim($line);
            if (!$line || $line[0] === '#' || !str_contains($line, '=')) continue;
            [$k, $v] = explode('=', $line, 2);
            self::$env[trim($k)] = trim($v, " \t\"'");
        }
    }

    public static function get(string $key, string $default = ''): string {
        self::load();
        return self::$env[$key] ?? $default;
    }

    public static function apiKeys(): array {
        $raw = self::get('API_KEYS');
        return $raw ? array_map('trim', explode(',', $raw)) : [];
    }

    public static function isValidKey(string $key): bool {
        if (!$key) return false;
        foreach (self::apiKeys() as $valid) {
            if (hash_equals($valid, $key)) return true;
        }
        return false;
    }

    public static function cacheTtl(): int {
        return (int) self::get('CACHE_TTL', '120');
    }
}
