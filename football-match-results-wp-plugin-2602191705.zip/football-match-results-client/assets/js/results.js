/**
 * Football Match Results Client — results.js
 * แปลภาษาเวียดนาม → อังกฤษ (ปรับแต่งสำหรับข้อมูลผลการแข่งขัน)
 * พร้อม auto-refresh ทุก 2 นาที
 */
(function () {
    'use strict';

    // ── Translation Map (Results-specific) ──────────────────────────────────
    // ลำดับสำคัญ: patterns ยาวกว่าต้องอยู่ก่อน
    const TR = [
        // Score detail: "90 Phút [x-x]" → "FT [x-x]"  (ต้องก่อน "90 Phút")
        [/90 Phút \[(\d+)-(\d+)\]/g,  'FT [$1-$2]'],
        [/120 Phút \[(\d+)-(\d+)\]/g, 'AET [$1-$2]'],
        // Vòng patterns
        [/Vòng Loại Trực Tiếp/g,      'Knockout Round'],
        [/Vòng Loại/g,                'Qualifying'],
        [/Vòng (\d+)\/(\d+)/g,        'Round of $2'],
        [/Vòng (\d+)/g,               'Matchday $1'],
        // Headers
        [/Chủ nhà/g,                  'Home'],
        [/Khách/g,                    'Away'],
        [/Tỷ số/g,                   'Score'],
        // Stages
        [/Bán kết/g,                  'Semi-final'],
        [/Chung kết/g,               'Final'],
        [/Tứ kết/g,                 'Quarter-final'],
        // Match detail
        [/Lượt đi/g,                 '1st Leg'],
        [/Lượt về/g,                 '2nd Leg'],
        [/Tiến vào vòng trong/g,     '→ Advances'],
        [/90 Phút/g,                  'FT'],
        [/120 Phút/g,                 'AET'],
        [/Phút/g,                    'min'],
        // Countries
        [/Tây Ban Nha/g,             'Spain'],
        [/Phần Lan/g,                'Finland'],
        [/Ba Lan/g,                  'Poland'],
        [/Bồ Đào Nha/g,             'Portugal'],
        [/Bắc Ireland/g,             'N. Ireland'],
        [/Thụy Điển/g,               'Sweden'],
        [/Thụy Sĩ/g,                 'Switzerland'],
        [/Na Uy/g,                   'Norway'],
        [/Pháp/g,                    'France'],
        [/Hà Lan/g,                  'Netherlands'],
        [/Đức/g,                     'Germany'],
        [/Ý\b/g,                     'Italy'],
        [/Bỉ/g,                      'Belgium'],
        [/Áo\b/g,                    'Austria'],
        // Women's prefix
        [/Nữ /g,                     "Women's "],
    ];

    function translate(html) {
        return TR.reduce((s, [re, rep]) => s.replace(re, rep), html);
    }

    function fmtTime(ts) {
        if (!ts) return '';
        return new Date(ts * 1000).toLocaleTimeString('en-GB', { hour12: false, timeZone: 'Asia/Bangkok' });
    }

    // ── DOM Update ────────────────────────────────────────────────────────────
    function updateDOM(wrap, html, updatedAt) {
        const body   = wrap.querySelector('.fmr-body');
        const status = wrap.querySelector('.fmr-status');
        const time   = wrap.querySelector('.fmr-time');
        const dot    = wrap.querySelector('.fmr-dot');
        if (!body) return;

        body.style.transition = 'opacity .25s';
        body.style.opacity    = '0';
        setTimeout(() => {
            body.innerHTML     = translate(html);
            body.style.opacity = '1';
            if (status) status.textContent = 'Live';
            if (time)   time.textContent   = 'Updated ' + fmtTime(updatedAt);
            if (dot)    dot.classList.add('active');
        }, 250);
    }

    function setError(wrap, msg) {
        const status = wrap.querySelector('.fmr-status');
        const dot    = wrap.querySelector('.fmr-dot');
        if (status) status.textContent = '⚠ ' + msg;
        if (dot)    dot.classList.remove('active');
    }

    // ── Fetch ─────────────────────────────────────────────────────────────────
    async function fetchResults(wrap) {
        try {
            const res = await fetch(FMRClient.proxy_url, {
                headers: { 'X-WP-Nonce': FMRClient.nonce },
                cache: 'no-store',
            });
            if (res.status === 503) { setError(wrap, 'Server unavailable'); return; }
            if (!res.ok)            { setError(wrap, 'Error ' + res.status);  return; }

            const data = await res.json();
            if (!data.success) { setError(wrap, data.error || 'No data'); return; }

            updateDOM(wrap, data.html, data.updated_at);
        } catch (e) {
            setError(wrap, 'Connection failed');
            console.warn('[FMR]', e);
        }
    }

    // ── Init ──────────────────────────────────────────────────────────────────
    function init(wrap) {
        fetchResults(wrap);
        if (wrap.dataset.autoRefresh === '1') {
            setInterval(() => fetchResults(wrap), FMRClient.interval);
        }
    }

    function boot() {
        document.querySelectorAll('.fmr-widget').forEach(init);
    }

    document.readyState === 'loading'
        ? document.addEventListener('DOMContentLoaded', boot)
        : boot();

    // Elementor editor
    if (typeof elementorFrontend !== 'undefined') {
        elementorFrontend.hooks.addAction(
            'frontend/element_ready/football_match_results.default',
            ($s) => { const w = $s[0]?.querySelector('.fmr-widget'); if (w) init(w); }
        );
    }
})();
