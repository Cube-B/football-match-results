<?php
if (!defined('ABSPATH')) exit;

class FMR_ApiClient {
    public static function fetch(string $apiUrl, string $apiKey): array {
        $response = wp_remote_get($apiUrl, [
            'timeout'    => 12,
            'user-agent' => 'FMRClient/1.0 (+'.get_site_url().')',
            'headers'    => ['X-Yamcha-Key'=>$apiKey,'Accept'=>'application/json'],
        ]);
        if (is_wp_error($response))
            return self::err('ไม่สามารถเชื่อมต่อ yamcha.info: '.$response->get_error_message());

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        return match(true) {
            $code===401 => self::err('API Key ไม่ถูกต้อง'),
            $code===429 => self::err('Rate limit exceeded'),
            $code===503 => self::err('yamcha.info cache ยังไม่พร้อม'),
            $code!==200 => self::err("HTTP $code"),
            !is_array($data) => self::err('Response format ไม่ถูกต้อง'),
            empty($data['success']) => self::err($data['error']??'Unknown error'),
            default => [
                'success'     => true,
                'html'        => $data['html']        ?? '',
                'updated_at'  => $data['updated_at']  ?? null,
                'updated_iso' => $data['updated_iso'] ?? null,
                'cache_age'   => $data['cache_age']   ?? null,
            ],
        };
    }
    private static function err(string $msg): array {
        error_log("[FMR Client] $msg");
        return ['success'=>false,'error'=>$msg];
    }
}
