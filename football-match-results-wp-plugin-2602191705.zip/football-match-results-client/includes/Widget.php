<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if (!defined('ABSPATH')) exit;

class FMR_Widget extends Widget_Base {
    public function get_name()       { return 'football_match_results'; }
    public function get_title()      { return '🏆 Football Match Results'; }
    public function get_icon()       { return 'eicon-table'; }
    public function get_categories() { return ['general']; }
    public function get_keywords()   { return ['football','soccer','results','score','yamcha']; }

    protected function register_controls(): void {
        $this->start_controls_section('sec_content',['label'=>'⚙️ Settings','tab'=>Controls_Manager::TAB_CONTENT]);
        $this->add_control('auto_refresh',['label'=>'Auto Refresh (ทุก 2 นาที)','type'=>Controls_Manager::SWITCHER,'return_value'=>'yes','default'=>'yes']);
        $this->add_control('show_topbar',['label'=>'แสดงแถบสถานะด้านบน','type'=>Controls_Manager::SWITCHER,'return_value'=>'yes','default'=>'yes']);
        $this->add_control('loading_text',['label'=>'Loading Text','type'=>Controls_Manager::TEXT,'default'=>'🏆 กำลังโหลดผลการแข่งขัน…']);
        $this->end_controls_section();

        $this->start_controls_section('sec_style',['label'=>'🎨 Style','tab'=>Controls_Manager::TAB_STYLE]);
        $this->add_control('bg_color',['label'=>'Background','type'=>Controls_Manager::COLOR,'default'=>'#0f1117','selectors'=>['{{WRAPPER}} .fmr-widget'=>'background-color: {{VALUE}}']]);
        $this->add_control('text_color',['label'=>'Text Color','type'=>Controls_Manager::COLOR,'default'=>'#e0e0e0','selectors'=>['{{WRAPPER}} .fmr-widget'=>'color: {{VALUE}}']]);
        $this->add_control('max_height',['label'=>'Max Height','type'=>Controls_Manager::SLIDER,'size_units'=>['px','vh'],'range'=>['px'=>['min'=>300,'max'=>2000],'vh'=>['min'=>30,'max'=>100]],'default'=>['unit'=>'px','size'=>800],'selectors'=>['{{WRAPPER}} .fmr-scroll'=>'max-height: {{SIZE}}{{UNIT}}']]);
        $this->end_controls_section();
    }

    protected function render(): void {
        $s  = $this->get_settings_for_display();
        $id = 'fmr-'.$this->get_id();
        wp_enqueue_style('fmr-client');
        wp_enqueue_script('fmr-client');
        self::renderWidget($id, $s['auto_refresh']==='yes', $s['show_topbar']==='yes', $s['loading_text']);
    }

    public static function renderWidget(string $id, bool $autoRefresh, bool $showTopbar, string $loading): void { ?>
        <div class="fmr-widget"
             id="<?= esc_attr($id) ?>"
             data-auto-refresh="<?= $autoRefresh?'1':'0' ?>"
             data-loading="<?= esc_attr($loading) ?>">
            <?php if ($showTopbar): ?>
            <div class="fmr-topbar">
                <span class="fmr-dot"></span>
                <span class="fmr-status">กำลังเชื่อมต่อ…</span>
                <span class="fmr-time"></span>
            </div>
            <?php endif; ?>
            <div class="fmr-scroll">
                <div class="fmr-body">
                    <div class="fmr-loading">
                        <div class="fmr-spinner"></div>
                        <p><?= esc_html($loading) ?></p>
                    </div>
                </div>
            </div>
        </div>
    <?php }
}

// Shortcode: [football_match_results height="800px"]
add_shortcode('football_match_results', function ($atts) {
    $a = shortcode_atts(['height'=>'800px','auto_refresh'=>'yes','show_topbar'=>'yes','loading'=>'🏆 กำลังโหลดผลการแข่งขัน…'], $atts);
    wp_enqueue_style('fmr-client');
    wp_enqueue_script('fmr-client');
    $id = 'fmr-sc-'.uniqid();
    ob_start();
    echo '<style>#'.esc_attr($id).' .fmr-scroll{max-height:'.esc_attr($a['height']).'}</style>';
    FMR_Widget::renderWidget($id, $a['auto_refresh']==='yes', $a['show_topbar']==='yes', $a['loading']);
    return ob_get_clean();
});
