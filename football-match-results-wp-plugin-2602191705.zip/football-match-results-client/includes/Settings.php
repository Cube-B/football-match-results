<?php
if (!defined('ABSPATH')) exit;

class FMR_Settings {
    const OPT = 'fmr_client_options';

    public static function getOptions(): array {
        $opts = get_option(self::OPT, ['center_url'=>'','api_key'=>'']);
        if (!empty($opts['api_key'])) $opts['api_key'] = self::decrypt($opts['api_key']);
        return $opts;
    }

    public static function register(): void {
        register_setting(self::OPT.'_group', self::OPT, ['sanitize_callback'=>[__CLASS__,'sanitize']]);
    }

    public static function sanitize(array $in): array {
        $out = [];
        $out['center_url'] = esc_url_raw(trim($in['center_url'] ?? ''));
        $raw = sanitize_text_field(trim($in['api_key'] ?? ''));
        if ($raw === '***UNCHANGED***') {
            $existing = get_option(self::OPT, []);
            $out['api_key'] = $existing['api_key'] ?? '';
        } elseif ($raw) {
            $out['api_key'] = self::encrypt($raw);
        } else {
            $out['api_key'] = '';
        }
        return $out;
    }

    private static function encrypt(string $d): string {
        $key = defined('AUTH_KEY') ? AUTH_KEY : 'fmr_fallback';
        $iv  = openssl_random_pseudo_bytes(16);
        $enc = openssl_encrypt($d, 'AES-256-CBC', hash('sha256',$key,true), 0, $iv);
        return base64_encode($iv.'::'.$enc);
    }

    private static function decrypt(string $d): string {
        try {
            $key = defined('AUTH_KEY') ? AUTH_KEY : 'fmr_fallback';
            [$iv,$enc] = explode('::', base64_decode($d), 2);
            return openssl_decrypt($enc,'AES-256-CBC',hash('sha256',$key,true),0,$iv)?:'';
        } catch(\Throwable){return '';}
    }

    public static function renderPage(): void {
        $opts   = self::getOptions();
        $masked = !empty($opts['api_key']) ? substr($opts['api_key'],0,10).'••••••••' : '';
        $tested = isset($_GET['test']) ? self::testConn($opts) : null;
        ?>
        <div class="wrap">
            <h1>🏆 Football Match Results — Settings</h1>
            <?php if ($tested): ?>
            <div class="notice notice-<?= $tested['ok']?'success':'error' ?> is-dismissible">
                <p><?= $tested['ok'] ? '✅ Connection OK — results data received' : '❌ '.esc_html($tested['error']) ?></p>
            </div>
            <?php endif; ?>

            <form method="post" action="options.php">
                <?php settings_fields(self::OPT.'_group'); ?>
                <table class="form-table">
                    <tr>
                        <th><label for="center_url">🌐 Yamcha Center URL</label></th>
                        <td>
                            <input type="url" id="center_url" name="<?= self::OPT ?>[center_url]"
                                   value="<?= esc_attr($opts['center_url']) ?>" class="regular-text"
                                   placeholder="https://yamcha.info/football-match-results" required>
                            <p class="description">URL ของโฟลเดอร์ football-match-results บน yamcha.info</p>
                        </td>
                    </tr>
                    <tr>
                        <th><label>🔑 API Key</label></th>
                        <td>
                            <?php if ($masked): ?>
                                <p>Key ปัจจุบัน: <code><?= esc_html($masked) ?></code></p>
                                <label><input type="checkbox" id="chk"
                                    onchange="document.getElementById('kf').style.display=this.checked?'block':'none';
                                              document.getElementById('kh').disabled=this.checked;">
                                    เปลี่ยน API Key</label>
                                <div id="kf" style="display:none;margin-top:8px">
                                    <input type="text" name="<?= self::OPT ?>[api_key]" class="regular-text" placeholder="ใส่ Key ใหม่">
                                </div>
                                <input type="hidden" id="kh" name="<?= self::OPT ?>[api_key]" value="***UNCHANGED***">
                            <?php else: ?>
                                <input type="text" name="<?= self::OPT ?>[api_key]" class="regular-text"
                                       placeholder="key_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" required>
                                <p class="description">ขอ Key จากผู้ดูแล yamcha.info</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
                <p class="submit">
                    <?php submit_button('💾 Save Settings','primary','submit',false); ?>
                    &nbsp;<a href="?page=fmr-client&test=1" class="button">🧪 Test Connection</a>
                </p>
            </form>
            <hr>
            <h2>📋 Shortcode</h2>
            <code style="background:#f0f0f0;padding:6px 12px;border-radius:4px">
                [football_match_results height="800px" auto_refresh="yes"]
            </code>
        </div>
        <?php
    }

    private static function testConn(array $opts): array {
        if (empty($opts['center_url'])||empty($opts['api_key']))
            return ['ok'=>false,'error'=>'กรุณาตั้งค่า Center URL และ API Key ก่อน'];
        $r = FMR_ApiClient::fetch(rtrim($opts['center_url'],'/').'/api.php',$opts['api_key']);
        return $r['success'] ? ['ok'=>true] : ['ok'=>false,'error'=>$r['error']??'Unknown error'];
    }
}
