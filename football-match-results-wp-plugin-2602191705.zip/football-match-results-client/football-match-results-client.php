<?php
/**
 * Plugin Name: Football Match Results Client
 * Plugin URI:  https://yamcha.info
 * Description: แสดงผลการแข่งขันฟุตบอล ดึงข้อมูลจาก yamcha.info (ต้องมี API Key)
 * Version:     1.0.0
 * Author:      Yamcha
 * Requires PHP: 8.0
 * Text Domain: fmr-client
 */

if (!defined('ABSPATH')) exit;

define('FMR_CLIENT_PATH', plugin_dir_path(__FILE__));
define('FMR_CLIENT_URL',  plugin_dir_url(__FILE__));
define('FMR_CLIENT_VER',  '1.0.0');

require_once FMR_CLIENT_PATH . 'includes/Settings.php';
require_once FMR_CLIENT_PATH . 'includes/ApiClient.php';

// Elementor Widget
add_action('elementor/widgets/register', function ($mgr) {
    require_once FMR_CLIENT_PATH . 'includes/Widget.php';
    $mgr->register(new FMR_Widget());
});

// Assets
add_action('wp_enqueue_scripts', function () {
    wp_register_style('fmr-client',  FMR_CLIENT_URL . 'assets/css/results.css',  [], FMR_CLIENT_VER);
    wp_register_script('fmr-client', FMR_CLIENT_URL . 'assets/js/results.js', [], FMR_CLIENT_VER, true);
    wp_localize_script('fmr-client', 'FMRClient', [
        'proxy_url' => rest_url('fmr-client/v1/results'),
        'nonce'     => wp_create_nonce('wp_rest'),
        'interval'  => 120000,
    ]);
});

// REST Proxy (Key ส่งจาก PHP เท่านั้น ไม่ผ่าน browser)
add_action('rest_api_init', function () {
    register_rest_route('fmr-client/v1', '/results', [
        'methods'             => 'GET',
        'callback'            => 'fmr_client_proxy',
        'permission_callback' => '__return_true',
    ]);
});

function fmr_client_proxy(): WP_REST_Response {
    $opts = FMR_Settings::getOptions();
    $url  = rtrim($opts['center_url'] ?? '', '/') . '/api.php';
    $key  = $opts['api_key'] ?? '';
    if (!$url || !$key) {
        return new WP_REST_Response(['success'=>false,'error'=>'Plugin not configured'], 503);
    }
    $result = FMR_ApiClient::fetch($url, $key);
    return new WP_REST_Response($result, $result['success'] ? 200 : 503);
}

// Admin
add_action('admin_menu', function () {
    add_options_page('Football Match Results', 'Football Match Results',
        'manage_options', 'fmr-client', ['FMR_Settings', 'renderPage']);
});
add_action('admin_init', ['FMR_Settings', 'register']);
